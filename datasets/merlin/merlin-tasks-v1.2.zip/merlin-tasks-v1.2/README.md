# MERLIN Corpus v1.2 - Tasks

MERLIN Corpus v1.2 - Tasks contains information about the tasks included 
in the MERLIN corpus.

**URL:** http://merlin-platform.eu

**Contact:** info@merlin-platform.eu

**Changelog:** [CHANGELOG](CHANGELOG.md)

## Tasks

- `docs`: documentation about writing task grids
- `grid`: PDF writing task grids
- `text`: XML excerpts of relevant plain text information from the 
  tasks (`<reading>`, `<question>`)

## Description

The MERLIN corpus is a written learner corpus for Czech, German, and 
Italian that has been designed to illustrate the Common European 
Framework of Reference for Languages (CEFR) with authentic learner data. 
The corpus contains learner texts produced in standardized language 
certifications covering CEFR levels A1-C1. The MERLIN annotation scheme 
includes a wide range of language characteristics that provide 
researchers with concrete examples of learner performance and progress 
across multiple proficiency levels.

## Details

**Date issued:** 2018-08

**Language(s):** Czech, German, Italian

**Acknowledgement:** EU Lifelong Learning Programme
518989-LLP-1-2011-1-DE-KA2-KA2MP

**Disclaimer:** This project has been funded with support from the 
European Commission. This website reflects the views only of the author, 
and the Commission cannot be held responsible for any use which may be 
made of the information contained therein.
