# MERLIN Corpus v1.2 - Solr

MERLIN Corpus v1.2 - Solr contains the solr `<add><doc/></add>` XML 
files for adding documents to the solr index as used in the simple 
search interface in the MERLIN platform.

Included:

- learner texts 
- learner and task metadata
- CEFR ratings
- target hypotheses
- indicators derived from learner language features
- complexity measures (German only)

Not included:

- transcription annotation
- learner language features (error annotation, etc.)
- automatic POS, lemmas, and repetitions
- automatic dependency parses

**URL:** http://merlin-platform.eu

**Contact:** info@merlin-platform.eu

**Changelog:** [CHANGELOG](CHANGELOG.md)

## Solr Format Notes

This format can be used to add documents to a solr index. See [Uploading 
Data with Index 
Handlers](http://lucene.apache.org/solr/guide/6_6/uploading-data-with-index-handlers.html).

## Description

The MERLIN corpus is a written learner corpus for Czech, German, and 
Italian that has been designed to illustrate the Common European 
Framework of Reference for Languages (CEFR) with authentic learner data. 
The corpus contains learner texts produced in standardized language 
certifications covering CEFR levels A1-C1. The MERLIN annotation scheme 
includes a wide range of language characteristics that provide 
researchers with concrete examples of learner performance and progress 
across multiple proficiency levels.

## Authors

- Katrin Wisniewski
- Andrea Abel
- Kateřina Vodičková
- Sybille Plassmann
- Detmar Meurers
- Claudia Woldt
- Karin Schöne
- Verena Blaschitz
- Verena Lyding
- Lionel Nicolas
- Chiara Vettori
- Pavel Pečený
- Jirka Hana
- Veronika Čurdová
- Barbora Štindlová
- Gudrun Klein
- Louise Lauppe
- Adriane Boyd
- Serhiy Bykh
- Julia Krivanek

## Details

**Date issued:** 2018-08

**Size:** 2287 texts

**Language(s):** Czech, German, Italian

**Acknowledgement:** EU Lifelong Learning Programme
518989-LLP-1-2011-1-DE-KA2-KA2MP

**Disclaimer:** This project has been funded with support from the 
European Commission. This website reflects the views only of the author, 
and the Commission cannot be held responsible for any use which may be 
made of the information contained therein.
